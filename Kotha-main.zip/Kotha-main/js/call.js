import { API_BASE, isNative } from "./config.js";
import { t } from "./i18n.js";

const RING_MS = 45000;
const STALE_MS = 90000;
const DROP_MS = 12000;
const CAND_DELAY = 250;
const FALLBACK_ICE = [{ urls: "stun:stun.l.google.com:19302" }];
const endText = status => ({ ended: t("call.ended"), declined: t("call.declined"), missed: t("call.missed") }[status]);

const fmt = s => Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");

const mediaError = err => {
  const n = err && err.name;
  if (n === "NotAllowedError" || n === "SecurityError") return t("call.micCamPermission");
  if (n === "NotFoundError" || n === "OverconstrainedError") return t("call.micCamMissing");
  if (n === "NotReadableError") return t("call.micCamBusy");
  return t("call.startFail");
};

export function createCalls({ auth, db, fs, push, $, toast, pic, getActive, getUsers, send, askChoice }) {
  const { collection, doc, getDoc, setDoc, updateDoc, addDoc, onSnapshot, query, where, serverTimestamp } = fs;

  let call = null;
  let watchUnsub = null;
  let iceCache = null;
  let audioCtx = null;
  let toneTimer = null;
  let hideTimer = null;
  let drag = null;
  let canRoute = false;

  const myUid = () => auth.currentUser?.uid || "";
  const nativeAudio = isNative ? window.Capacitor.Plugins?.CallAudio || null : null;

  const syncNativeSpeaker = () => {
    if (!nativeAudio) return;
    nativeAudio.isSpeaker().then(r => $("callSpeaker").classList.toggle("on", !!r.on)).catch(() => {});
  };

  const startNativeAudio = video => {
    if (!nativeAudio) return;
    nativeAudio.start({ speaker: !!video }).then(syncNativeSpeaker).catch(() => {});
  };

  const stopNativeAudio = () => {
    if (nativeAudio) nativeAudio.stop().catch(() => {});
  };

  const newCall = base => ({
    ...base,
    id: "",
    ref: null,
    pc: null,
    local: null,
    remote: null,
    data: null,
    created: false,
    accepted: false,
    connected: false,
    weak: false,
    ended: false,
    canSend: false,
    peerCamOff: false,
    facing: "user",
    out: [],
    pending: [],
    unsubs: [],
    startedAt: 0,
    tick: null,
    ringTimer: null,
    dropTimer: null,
    outTimer: null,
    wake: null,
    notif: null
  });

  const setStatus = text => {
    $("callStatus").textContent = text;
  };

  const stopTone = () => {
    if (toneTimer) clearInterval(toneTimer);
    toneTimer = null;
    if (navigator.vibrate) navigator.vibrate(0);
  };

  const beep = (freq, at, dur, vol) => {
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = "sine";
    o.frequency.value = freq;
    o.connect(g);
    g.connect(audioCtx.destination);
    g.gain.setValueAtTime(0, at);
    g.gain.linearRampToValueAtTime(vol, at + 0.03);
    g.gain.linearRampToValueAtTime(0, at + dur);
    o.start(at);
    o.stop(at + dur + 0.05);
  };

  const startTone = kind => {
    stopTone();
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.resume) audioCtx.resume();
    } catch {
      return;
    }
    const play = () => {
      try {
        const at = audioCtx.currentTime + 0.05;
        if (kind === "in") {
          beep(880, at, 0.35, 0.2);
          beep(660, at + 0.4, 0.35, 0.2);
          beep(880, at + 1.0, 0.35, 0.2);
          beep(660, at + 1.4, 0.35, 0.2);
          if (navigator.vibrate) navigator.vibrate([400, 200, 400]);
        } else {
          beep(440, at, 1.0, 0.12);
        }
      } catch {
        return;
      }
    };
    play();
    toneTimer = setInterval(play, 3000);
  };

  async function getIce() {
    if (iceCache && iceCache.exp > Date.now()) return iceCache.servers;
    try {
      const token = await auth.currentUser.getIdToken();
      const r = await fetch(API_BASE + "/api/turn", {
        headers: { Authorization: "Bearer " + token },
        cache: "no-store",
        signal: AbortSignal.timeout ? AbortSignal.timeout(6000) : undefined
      });
      if (r.ok) {
        const j = await r.json();
        if (Array.isArray(j.iceServers) && j.iceServers.length) {
          if (j.relay) iceCache = { servers: j.iceServers, exp: Date.now() + 30 * 60000 };
          return j.iceServers;
        }
      }
    } catch {
      return FALLBACK_ICE;
    }
    return FALLBACK_ICE;
  }

  const getMedia = video => navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    video: video ? { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } } : false
  });

  const paintPeer = u => {
    $("callImg").src = pic(u || { name: "?" });
    $("callName").textContent = (u && u.name) || "";
  };

  function layout(c) {
    const rv = !!c.remote && c.remote.getVideoTracks().length > 0 && !c.peerCamOff;
    $("call").classList.toggle("vid", rv && c.connected);
    $("localWrap").hidden = !(c.video && c.local && c.local.getVideoTracks().length);
    if (!c.video || !c.connected) stopHideTimer();
  }

  function stopHideTimer() {
    clearTimeout(hideTimer);
    hideTimer = null;
    $("call").classList.remove("hide-ui");
  }

  function armHideTimer(c) {
    clearTimeout(hideTimer);
    if (!c.video || !c.connected) return;
    hideTimer = setTimeout(() => {
      if (call === c && c.connected) $("call").classList.add("hide-ui");
    }, 4000);
  }

  function showCall(c, text) {
    const u = getUsers().get(c.peerUid);
    paintPeer(u);
    if (!u) {
      getDoc(doc(db, "users", c.peerUid)).then(s => {
        if (s.exists() && call === c) paintPeer(s.data());
      }).catch(() => {});
    }
    const box = $("call");
    box.className = "ring";
    setStatus(text);
    $("callIn").hidden = c.dir !== "in";
    $("callBar").hidden = c.dir === "in";
    $("callCam").hidden = !c.video;
    $("callFlip").hidden = !c.video;
    setLocalPos(16, 16);
    $("callMute").classList.remove("off");
    $("callCam").classList.remove("off");
    $("callSpeaker").classList.remove("on");
    $("localVideo").classList.remove("off", "back");
    $("localVideo").srcObject = null;
    $("remoteVideo").srcObject = null;
    $("localWrap").hidden = true;
    box.hidden = false;
    stopHideTimer();
    setupSpeaker();
  }

  const hideCall = () => {
    stopHideTimer();
    $("call").hidden = true;
    $("localVideo").srcObject = null;
    $("remoteVideo").srcObject = null;
  };

  function queueCand(c, cand) {
    c.out.push(cand);
    if (!c.canSend) return;
    clearTimeout(c.outTimer);
    c.outTimer = setTimeout(() => flushOut(c), CAND_DELAY);
  }

  function flushOut(c) {
    if (!c.canSend || c.ended || !c.out.length) return;
    const cs = c.out;
    c.out = [];
    addDoc(collection(db, "calls", c.id, "candidates"), { from: myUid(), cs }).catch(() => {});
  }

  async function applyCand(c, cand) {
    if (c.ended || !c.pc) return;
    if (!c.pc.remoteDescription) {
      c.pending.push(cand);
      return;
    }
    try {
      await c.pc.addIceCandidate(cand);
    } catch {
      return;
    }
  }

  async function flushPending(c) {
    const list = c.pending;
    c.pending = [];
    for (const x of list) {
      try {
        await c.pc.addIceCandidate(x);
      } catch {
        continue;
      }
    }
  }

  function watchCandidates(c) {
    const uid = myUid();
    c.unsubs.push(onSnapshot(collection(db, "calls", c.id, "candidates"), s => {
      s.docChanges().forEach(ch => {
        if (ch.type !== "added") return;
        const d = ch.doc.data();
        if (d.from === uid) return;
        (d.cs || []).forEach(x => applyCand(c, x));
      });
    }));
  }

  function onConnected(c) {
    if (c.ended) return;
    c.weak = false;
    clearTimeout(c.dropTimer);
    if (c.connected) return;
    c.connected = true;
    c.startedAt = Date.now();
    clearTimeout(c.ringTimer);
    stopTone();
    $("call").classList.remove("ring");
    setStatus("0:00");
    c.tick = setInterval(() => {
      if (!c.weak) setStatus(fmt(Math.floor((Date.now() - c.startedAt) / 1000)));
    }, 1000);
    layout(c);
    armHideTimer(c);
    if (navigator.vibrate) navigator.vibrate(60);
  }

  function makePeer(c, stream, ice) {
    const pc = new RTCPeerConnection({ iceServers: ice });
    c.pc = pc;
    c.local = stream;
    c.remote = null;
    stream.getTracks().forEach(track => pc.addTrack(track, stream));
    $("localVideo").srcObject = c.video ? stream : null;
    pc.ontrack = e => {
      c.remote = e.streams[0] || c.remote || new MediaStream([e.track]);
      const rv = $("remoteVideo");
      if (rv.srcObject !== c.remote) rv.srcObject = c.remote;
      const p = rv.play();
      if (p && p.catch) p.catch(() => {});
      layout(c);
    };
    pc.onicecandidate = e => {
      if (e.candidate) {
        queueCand(c, e.candidate.toJSON());
        return;
      }
      clearTimeout(c.outTimer);
      flushOut(c);
    };
    pc.onconnectionstatechange = () => {
      if (c.ended) return;
      const st = pc.connectionState;
      if (st === "connected") {
        onConnected(c);
      } else if (st === "disconnected") {
        c.weak = true;
        setStatus(t("call.weak"));
        clearTimeout(c.dropTimer);
        c.dropTimer = setTimeout(() => {
          if (!c.ended && pc.connectionState !== "connected") finish(c, "ended", t("call.dropped"));
        }, DROP_MS);
      } else if (st === "failed") {
        finish(c, "ended", t("call.connectFail"));
      }
    };
    if (navigator.wakeLock) {
      navigator.wakeLock.request("screen").then(l => {
        if (c.ended) l.release().catch(() => {});
        else c.wake = l;
      }).catch(() => {});
    }
    layout(c);
    return pc;
  }

  function watchCall(c) {
    c.unsubs.push(onSnapshot(c.ref, snap => {
      if (c.ended || !snap.exists()) return;
      const d = snap.data();
      c.data = d;
      if (c.dir === "out" && d.answer && c.pc && !c.pc.remoteDescription) {
        stopTone();
        setStatus(t("call.connecting"));
        c.pc.setRemoteDescription(d.answer).then(() => flushPending(c)).catch(() => finish(c, "ended", t("call.setupFail")));
      }
      const off = d.cam ? d.cam[c.peerUid] === false : false;
      if (off !== c.peerCamOff) {
        c.peerCamOff = off;
        layout(c);
      }
      if (endText(d.status)) {
        const text = d.endReason === "busy" ? t("call.busy") : (c.dir === "out" && d.status === "missed" ? "" : endText(d.status));
        finish(c, d.status, text, true);
      }
    }));
  }

  function logCall(c, reason) {
    const icon = c.video ? "🎥" : "📞";
    const label = t(c.video ? "call.video" : "call.voice");
    const secs = Math.floor((Date.now() - c.startedAt) / 1000);
    let text;
    let kind;
    if (c.connected) {
      kind = "done";
      text = icon + " " + label + " · " + fmt(secs);
    } else if (reason === "declined") {
      kind = "declined";
      text = icon + " " + t("call.logDeclined", { label });
    } else if (reason === "ended") {
      kind = "cancelled";
      text = icon + " " + t("call.logCancelled", { label });
    } else {
      kind = "missed";
      text = icon + " " + t("call.logMissed", { label });
    }
    send({ type: "call", text: "", callLog: { kind, video: !!c.video, secs: kind === "done" ? Math.min(secs, 86399) : 0, callId: c.id } }, { id: c.chatId, members: [myUid(), c.peerUid], reply: null }).catch(() => {});
  }

  function finish(c, reason, text, remote) {
    if (c.ended) return;
    c.ended = true;
    clearTimeout(c.ringTimer);
    clearTimeout(c.dropTimer);
    clearTimeout(c.outTimer);
    clearInterval(c.tick);
    c.unsubs.forEach(u => u());
    c.unsubs = [];
    stopTone();
    if (c.notif) c.notif.close();
    if (c.wake) c.wake.release().catch(() => {});
    if (c.pc) {
      c.pc.onconnectionstatechange = null;
      c.pc.onicecandidate = null;
      c.pc.ontrack = null;
      c.pc.close();
    }
    if (c.local) c.local.getTracks().forEach(track => track.stop());
    stopNativeAudio();
    if (c.created && !remote) {
      const status = reason === "declined" || reason === "missed" ? reason : "ended";
      updateDoc(c.ref, { status, endedAt: serverTimestamp(), endReason: reason }).catch(() => {});
    }
    if (c.connected && c.created && c.ref) {
      const talked = Math.floor((Date.now() - c.startedAt) / 1000);
      updateDoc(c.ref, { secs: talked }).catch(() => {});
    }
    if (c.dir === "out" && c.created) logCall(c, reason);
    hideCall();
    if (call === c) call = null;
    if (text) toast(text);
  }

  const hangup = reason => {
    if (call) finish(call, reason, "");
  };

  async function startCall(video, target) {
    const active = target || getActive();
    const me = auth.currentUser;
    if (call || !me || !active || active.group || !active.peer) return;
    if (!window.RTCPeerConnection || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast(t("call.unsupported"));
      return;
    }
    const c = newCall({ dir: "out", video, peerUid: active.peer, chatId: active.id });
    call = c;
    showCall(c, t("call.calling"));
    startTone("out");
    startNativeAudio(video);
    let stream;
    let ice;
    try {
      [stream, ice] = await Promise.all([getMedia(video), getIce()]);
    } catch (err) {
      finish(c, "ended", mediaError(err));
      return;
    }
    if (c.ended) {
      stream.getTracks().forEach(track => track.stop());
      return;
    }
    try {
      const pc = makePeer(c, stream, ice);
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      if (c.ended) return;
      c.ref = doc(collection(db, "calls"));
      c.id = c.ref.id;
      await setDoc(c.ref, {
        caller: me.uid,
        callee: c.peerUid,
        chatId: c.chatId,
        video,
        status: "ringing",
        offer: { type: offer.type, sdp: offer.sdp },
        createdAt: serverTimestamp()
      });
      c.created = true;
      if (c.ended) {
        updateDoc(c.ref, { status: "ended", endedAt: serverTimestamp(), endReason: "ended" }).catch(() => {});
        return;
      }
      if (push) push({ type: "call", callId: c.id });
      setStatus(t("call.ringing"));
      watchCall(c);
      watchCandidates(c);
      c.canSend = true;
      flushOut(c);
      c.ringTimer = setTimeout(() => {
        if (!c.connected && !c.ended) finish(c, "missed", t("call.noAnswer"));
      }, RING_MS);
    } catch (err) {
      finish(c, "ended", t("call.startFail"));
    }
  }

  function incoming(id, ref, d) {
    const c = newCall({ dir: "in", video: !!d.video, peerUid: d.caller, chatId: d.chatId });
    c.id = id;
    c.ref = ref;
    c.data = d;
    c.created = true;
    call = c;
    showCall(c, t(d.video ? "call.incomingVideo" : "call.incomingVoice"));
    startTone("in");
    if (document.hidden && "Notification" in window && Notification.permission === "granted") {
      try {
        const name = (getUsers().get(d.caller) || {}).name || "";
        c.notif = new Notification(t(d.video ? "call.incomingVideo" : "call.incomingVoice"), { body: name, icon: "icon-192.png", tag: "call-" + id, requireInteraction: true });
        c.notif.onclick = () => {
          window.focus();
          c.notif.close();
        };
      } catch {
        c.notif = null;
      }
    }
    c.ringTimer = setTimeout(() => {
      if (!c.accepted && !c.ended) finish(c, "missed", t("call.missed"), true);
    }, RING_MS + 5000);
  }

  async function accept() {
    const c = call;
    if (!c || c.dir !== "in" || c.accepted || c.ended) return;
    c.accepted = true;
    stopTone();
    clearTimeout(c.ringTimer);
    if (c.notif) c.notif.close();
    $("callIn").hidden = true;
    $("callBar").hidden = false;
    startNativeAudio(c.video);
    setStatus(t("call.connecting"));
    if (!window.RTCPeerConnection || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      finish(c, "declined", t("call.unsupported"));
      return;
    }
    let stream;
    let ice;
    try {
      [stream, ice] = await Promise.all([getMedia(c.video), getIce()]);
    } catch (err) {
      finish(c, "declined", mediaError(err));
      return;
    }
    if (c.ended) {
      stream.getTracks().forEach(track => track.stop());
      return;
    }
    try {
      const pc = makePeer(c, stream, ice);
      await pc.setRemoteDescription(c.data.offer);
      watchCandidates(c);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      if (c.ended) return;
      const fresh = await getDoc(c.ref);
      if (!fresh.exists() || fresh.data().status !== "ringing") {
        finish(c, "missed", t("call.alreadyEnded"), true);
        return;
      }
      await updateDoc(c.ref, { answer: { type: answer.type, sdp: answer.sdp }, status: "active" });
      c.canSend = true;
      flushOut(c);
      watchCall(c);
    } catch (err) {
      finish(c, "ended", t("call.answerFail"));
    }
  }

  function toggleMute() {
    const c = call;
    if (!c || !c.local) return;
    const tracks = c.local.getAudioTracks();
    if (!tracks.length) return;
    const on = !tracks[0].enabled;
    tracks.forEach(track => { track.enabled = on; });
    $("callMute").classList.toggle("off", !on);
  }

  function toggleCam() {
    const c = call;
    if (!c || !c.local) return;
    const tracks = c.local.getVideoTracks();
    if (!tracks.length) return;
    const on = !tracks[0].enabled;
    tracks.forEach(track => { track.enabled = on; });
    $("callCam").classList.toggle("off", !on);
    $("localVideo").classList.toggle("off", !on);
    if (c.created && c.ref) updateDoc(c.ref, { ["cam." + myUid()]: on }).catch(() => {});
  }

  const outLabel = d => {
    const l = (d.label || "").toLowerCase();
    if (/speaker/.test(l)) return t("call.route.speaker");
    if (/earpiece|receiver/.test(l)) return t("call.route.earpiece");
    if (/bluetooth/.test(l)) return t("call.route.bluetooth");
    if (/headphone|headset|wired/.test(l)) return t("call.route.headphones");
    return d.label || t("call.route.default");
  };

  async function setupSpeaker() {
    if (nativeAudio) {
      canRoute = true;
      $("callSpeaker").classList.remove("dim");
      return;
    }
    canRoute = false;
    $("callSpeaker").classList.add("dim");
    if (!("setSinkId" in HTMLMediaElement.prototype) || !navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;
    try {
      const list = await navigator.mediaDevices.enumerateDevices();
      const outs = list.filter(d => d.kind === "audiooutput" && d.deviceId);
      canRoute = outs.length > 1;
      $("callSpeaker").classList.toggle("dim", !canRoute);
    } catch {
      return;
    }
  }

  async function pickSpeaker() {
    if (!call) return;
    if (nativeAudio) {
      const state = await nativeAudio.isSpeaker().catch(() => ({ on: false }));
      await nativeAudio.setSpeaker({ on: !state.on }).catch(() => {});
      syncNativeSpeaker();
      return;
    }
    if (!askChoice) return;
    if (!canRoute) {
      toast(t("call.audioUnsupported"));
      return;
    }
    let outs;
    try {
      const list = await navigator.mediaDevices.enumerateDevices();
      outs = list.filter(d => d.kind === "audiooutput" && d.deviceId);
    } catch {
      return;
    }
    if (!outs.length) return;
    const value = await askChoice({
      title: t("call.audioTitle"),
      text: t("call.audioText"),
      iconName: "users",
      options: [
        ...outs.map(d => ({ label: outLabel(d), value: d.deviceId, kind: "dcancel" })),
        { label: t("common.cancel"), value: "", kind: "dcancel" }
      ]
    });
    if (!value || !call) return;
    try {
      await $("remoteVideo").setSinkId(value);
      const speakerLike = outs.find(d => d.deviceId === value && /speaker/i.test(d.label || ""));
      $("callSpeaker").classList.toggle("on", !!speakerLike);
    } catch {
      toast(t("call.audioFail"));
    }
  }

  function setLocalPos(top, right) {
    const wrap = $("localWrap");
    wrap.style.top = "max(" + top + "px, calc(env(safe-area-inset-top) + " + top + "px))";
    wrap.style.right = right + "px";
    wrap.style.left = "";
    wrap.style.bottom = "";
  }

  function initDrag() {
    const wrap = $("localWrap");
    let sx = 0;
    let sy = 0;
    let ox = 0;
    let oy = 0;
    wrap.addEventListener("pointerdown", e => {
      wrap.setPointerCapture(e.pointerId);
      const r = wrap.getBoundingClientRect();
      ox = r.left;
      oy = r.top;
      sx = e.clientX;
      sy = e.clientY;
      drag = { id: e.pointerId, moved: false };
      wrap.classList.add("drag");
    });
    wrap.addEventListener("pointermove", e => {
      if (!drag || drag.id !== e.pointerId) return;
      const dx = e.clientX - sx;
      const dy = e.clientY - sy;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) drag.moved = true;
      const w = wrap.offsetWidth;
      const h = wrap.offsetHeight;
      const x = Math.min(Math.max(ox + dx, 8), innerWidth - w - 8);
      const y = Math.min(Math.max(oy + dy, 8), innerHeight - h - 8);
      wrap.style.left = x + "px";
      wrap.style.top = y + "px";
      wrap.style.right = "";
      wrap.style.bottom = "";
    });
    const end = e => {
      if (!drag || drag.id !== e.pointerId) return;
      wrap.classList.remove("drag");
      drag = null;
    };
    wrap.addEventListener("pointerup", end);
    wrap.addEventListener("pointercancel", end);
  }

  async function flipCam() {
    const c = call;
    if (!c || !c.local || !c.pc) return;
    const old = c.local.getVideoTracks()[0];
    if (!old) return;
    const prev = c.facing;
    const next = prev === "user" ? "environment" : "user";
    const open = facing => navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 640 }, height: { ideal: 480 } } });
    const enabled = old.enabled;
    old.stop();
    let s;
    let used = next;
    try {
      s = await open(next);
    } catch {
      try {
        s = await open(prev);
        used = prev;
      } catch {
        toast(t("call.cameraFail"));
        return;
      }
    }
    if (c.ended) {
      s.getTracks().forEach(track => track.stop());
      return;
    }
    const track = s.getVideoTracks()[0];
    track.enabled = enabled;
    const sender = c.pc.getSenders().find(x => x.track && x.track.kind === "video");
    try {
      if (sender) await sender.replaceTrack(track);
    } catch {
      track.stop();
      toast(t("call.cameraFail"));
      return;
    }
    c.local.removeTrack(old);
    c.local.addTrack(track);
    c.facing = used;
    $("localVideo").srcObject = c.local;
    $("localVideo").classList.toggle("back", used === "environment");
  }

  function start(uid) {
    stop();
    const q = query(collection(db, "calls"), where("callee", "==", uid), where("status", "==", "ringing"));
    watchUnsub = onSnapshot(q, s => {
      s.docChanges().forEach(ch => {
        const d = ch.doc.data();
        if (ch.type === "removed") {
          const c = call;
          if (!c || c.dir !== "in" || c.id !== ch.doc.id || c.accepted || c.ended) return;
          const text = d.status === "active" ? t("call.answeredElsewhere") : t("call.missed");
          finish(c, "missed", text, true);
          return;
        }
        if (ch.type !== "added") return;
        const created = d.createdAt && d.createdAt.toMillis ? d.createdAt.toMillis() : 0;
        if (!created || Date.now() - created > STALE_MS) return;
        if (call) {
          if (call.id !== ch.doc.id) updateDoc(ch.doc.ref, { status: "declined", endedAt: serverTimestamp(), endReason: "busy" }).catch(() => {});
          return;
        }
        incoming(ch.doc.id, ch.doc.ref, d);
      });
    }, () => {});
  }

  function stop() {
    if (watchUnsub) watchUnsub();
    watchUnsub = null;
    if (call) finish(call, "ended", "");
  }

  $("voiceCallBtn").onclick = () => startCall(false);
  $("videoCallBtn").onclick = () => startCall(true);
  $("callAccept").onclick = accept;
  $("callDecline").onclick = () => hangup("declined");
  $("callEnd").onclick = () => hangup("ended");
  $("callMute").onclick = toggleMute;
  $("callCam").onclick = toggleCam;
  $("callFlip").onclick = flipCam;
  $("callSpeaker").onclick = pickSpeaker;
  initDrag();
  const wakeUi = () => {
    if (!call || !call.video || !call.connected) return;
    stopHideTimer();
    armHideTimer(call);
  };
  $("callTap").addEventListener("click", wakeUi);
  $("remoteVideo").addEventListener("click", wakeUi);
  addEventListener("pagehide", () => {
    if (call && call.created && !call.ended) hangup("ended");
  });

  const busy = () => {
    if (!call) return "";
    return call.dir === "in" && !call.accepted ? "in" : "on";
  };

  return { start, stop, busy, startCall };
}
